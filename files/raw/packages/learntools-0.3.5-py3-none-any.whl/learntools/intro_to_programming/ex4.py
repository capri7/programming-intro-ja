from learntools.core import *

def get_grade(score):
    if score >= 90:
        grade = "A"
    elif score >= 80:
        grade = "B"
    elif score >= 70:
        grade = "C"
    elif score >= 60:
        grade = "D"
    else:
        grade = "F"
    return grade

def get_water_bill(num_gallons):
    if num_gallons <= 8000:
        bill = 5 * num_gallons / 1000
    elif num_gallons <= 22000:
        bill = 6 * num_gallons / 1000
    elif num_gallons <= 30000:
        bill = 7 * num_gallons / 1000
    else:
        bill = 10 * num_gallons / 1000
    return bill

def get_phone_bill(gb):
    # 全員が毎月100ドルを支払います
    bill = 100
    # 15GBのプランを超過したGB数（下回っていれば負の値）
    gb_over = gb - 15
    # gb_over が正の値であれば、追加料金が発生します
    if gb_over > 0:
        # 超過分のGBに対する追加料金を計算します
        overage_fee = 100 * gb_over
        # 追加料金を請求額に加えます
        bill = bill + overage_fee
    return bill

class GetGrade(FunctionProblem):
    _var = 'get_grade'
    _test_cases = [(i, get_grade(i)) for i in range(0,101)]           
    _hint = (
        "スコアに応じて、次のように評価を分けてみましょう：\n\n"
        "- 90以上 → \"A\"\n"
        "- 80〜89 → \"B\"\n"
        "- 70〜79 → \"C\"\n"
        "- 60〜69 → \"D\"\n"
        "- 60未満 → \"F\"\n\n"
        "それぞれの条件を `if` / `elif` / `else` を使って書いてください。\n"
        "どんなスコアが来ても、必ず \"A\"〜\"F\" のどれかが返るようにしましょう。"
    )
    _solution = CS(
"""def get_grade(score):
    if score >= 90:
        grade = "A"
    elif score >= 80:
        grade = "B"
    elif score >= 70:
        grade = "C"
    elif score >= 60:
        grade = "D"
    else:
        grade = "F"
    return grade
""")

class CostProjectPartDeux(FunctionProblem):
    _var = 'cost_of_project'
    _test_cases = [
        (("Charlie+Denver", True), 240),
        (("08/10/2000", False), 120),
        (("Adrian", True), 160),
        (("Ana", False), 71),
    ]
    _hint = (
        "リングの素材によって、価格の計算方法が異なります。\n\n"
        "- `solid_gold = True` の場合：\n"
        "  基本料金は 100 ドル。刻印の長さ × 10 ドルが加算されます。\n\n"
        "- `solid_gold = False` の場合：\n"
        "  基本料金は 50 ドル。刻印の長さ × 7 ドルが加算されます。\n\n"
        "`len(engraving)` を使えば、刻印の文字数を取得できます。\n"
        "素材ごとの条件分岐を `if` 文で書いてみましょう。"
    )
    _solution = CS(
"""# option 1（変数を使って計算するスタイル）
# def cost_of_project(engraving, solid_gold):
#     num_units = len(engraving)
#     if solid_gold:
#         cost = 100 + 10 * num_units
#     else:
#         cost = 50 + 7 * num_units
#     return cost

# option 2（より簡潔に書くスタイル）
def cost_of_project(engraving, solid_gold):
    if solid_gold:
        cost = 100 + 10 * len(engraving)
    else:
        cost = 50 + 7 * len(engraving)
    return cost
"""
    )

class GetWaterBill(FunctionProblem):
    _var = 'get_water_bill'
    _test_cases = [(1000*i, get_water_bill(1000*i)) for i in range (0, 41)]
    _hint = """
        水道料金は、使用量に応じて次のように変化します：

        - 8000ガロン以下：1,000ガロンあたり5ドル
        - 8001〜22,000ガロン：1,000ガロンあたり6ドル
        - 22,001〜30,000ガロン：1,000ガロンあたり7ドル
        - 30,001ガロン以上：1,000ガロンあたり10ドル


        このルールを `if` / `elif` / `else` を使って、以下のような形で書いてみましょう：

        ```python
        def get_water_bill(num_gallons):
            if num_gallons <= 8000:
                bill = ____ 
            elif num_gallons <= 22000:
                bill = ____ 
            elif num_gallons <= 30000:
                bill = ____
            else:
                bill = ____ 
            return bill

        💡 num_gallons を 1000 で割って、単価を掛けて計算してみましょう。
    """
    _solution = CS(
"""def get_water_bill(num_gallons):
    if num_gallons <= 8000:
        bill = 5 * num_gallons / 1000
    elif num_gallons <= 22000:
        bill = 6 * num_gallons / 1000
    elif num_gallons <= 30000:
        bill = 7 * num_gallons / 1000
    else:
        bill = 10 * num_gallons / 1000
    return bill
""")

class GetPhoneBill(FunctionProblem):
    _var = 'get_phone_bill'
    _test_cases = [(5 + .5*i, get_phone_bill(5 + .5*i)) for i in range (0, 35)]
    _hint = """
        データ通信の料金は以下のルールに従って計算されます：

        - 使用量が 15GB 以下の場合は、一律で 100ドル。
        - 使用量が 15GB を超えた場合は、基本料金 100ドル に加えて、超過分 1GB ごとに 10ドルを加算します。

        このルールを反映するには、次のような構造を使うと良いでしょう：

        ```python
        def get_phone_bill(gb):
            if gb <= 15:
                bill = 100
            else:
                bill = 100 + ____  # 超過分をどう扱うか考えてみましょう
            return bill
        
        💡 gb - 15 を使うと、超過分のGB数を求められます。
    """        
    _solution = CS(
"""def get_phone_bill(gb):
    if gb <= 15:
        bill = 100
    else:
        bill = 100 + (gb - 15) * 100
    return bill
""")
    
class GetLabels(CodingProblem):
    _congrats = "すべての食品にラベルを付けることができたら、次のチュートリアルに進む準備ができています！"
    _correct_message = ""
    def check(self):
        pass


qnames = list(bind_exercises(globals(), [
    GetGrade,
    CostProjectPartDeux,
    GetWaterBill,
    GetPhoneBill,
    GetLabels
], var_format='q{n}'))

from learntools.core import binder
for name in qnames:
    globals()[name].globals = binder.readonly_globals()

__all__ = qnames
