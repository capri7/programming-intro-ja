from learntools.core import *

def get_grade(score):
    if score >= 90:
        grade = "A"
    elif score >= 80:
        grade = "B"
    elif score >= 70:
        grade = "C"
    elif score >= 60:
        grade = "D"
    else:
        grade = "F"
    return grade

def get_water_bill(num_gallons):
    if num_gallons <= 8000:
        bill = 5 * num_gallons / 1000
    elif num_gallons <= 22000:
        bill = 6 * num_gallons / 1000
    elif num_gallons <= 30000:
        bill = 7 * num_gallons / 1000
    else:
        bill = 10 * num_gallons / 1000
    return bill

def get_phone_bill(gb):
    # 全員が毎月100ドルを支払います
    bill = 100
    # 15GBのプランを超過したGB数（下回っていれば負の値）
    gb_over = gb - 15
    # gb_over が正の値であれば、追加料金が発生します
    if gb_over > 0:
        # 超過分のGBに対する追加料金を計算します
        overage_fee = 100 * gb_over
        # 追加料金を請求額に加えます
        bill = bill + overage_fee
    return bill

class GetGrade(FunctionProblem):
    _var = 'get_grade'
    _test_cases = [(i, get_grade(i)) for i in range(0,101)]           
    _hint = ('`"A"`を返すのは`score >= 90`の場合だけにしてください。それ以外の場合、スコアが80〜89、'
             '70〜79、60〜69、あるいは60未満であれば、それぞれ異なる成績を返す必要があります。'
             'あなたの関数は必ず `"A"`、`"B"`、`"C"`、`"D"`、`"F"` のいずれかを返すようにしてください。')
    _solution = CS(
"""def get_grade(score):
    if score >= 90:
        grade = "A"
    elif score >= 80:
        grade = "B"
    elif score >= 70:
        grade = "C"
    elif score >= 60:
        grade = "D"
    else:
        grade = "F"
    return grade
""")

class CostProjectPartDeux(FunctionProblem):
    _var = 'cost_of_project'
    _test_cases = [
        (("Charlie+Denver", True), 240),
        (("08/10/2000", False), 120),
        (("Adrian", True), 160),
        (("Ana", False), 71),
    ]
    _hint = ("`solid_gold = True`の場合、指輪の価格は基本料金の100ドルに、刻印の長さ×10ドルが加算されます。"
         "`len(engraving)`を使って刻印の長さを取得できます。"
         "一方で `solid_gold = False` の場合、価格は基本料金の50ドルに、刻印の長さ×7ドルが加算されます。")
    _solution = CS(
"""# option 1
def cost_of_project(engraving, solid_gold):
    num_units = len(engraving)
    if solid_gold == True:
        cost = 100 + 10 * num_units
    else:
        cost = 50 + 7 * num_units
    return cost
    
# option 2 
def cost_of_project(engraving, solid_gold):
    if solid_gold == True:
        cost = 100 + 10 * len(engraving)
    else:
        cost = 50 + 7 * len(engraving)
    return cost
""")
    
class GetWaterBill(FunctionProblem):
    _var = 'get_water_bill'
    _test_cases = [(1000*i, get_water_bill(1000*i)) for i in range (0, 41)]
    _hint = """
あなたの解答は次のようなコードになるはずです：
```python
def get_water_bill(num_gallons):
    if num_gallons <= 8000:
        bill = ____ 
    elif num_gallons <= 22000:
        bill = ____ 
    elif num_gallons <= 30000:
        bill = ____
    else:
        bill = ____ 
    return bill
```
"""
    _solution = CS(
"""def get_water_bill(num_gallons):
    if num_gallons <= 8000:
        bill = 5 * num_gallons / 1000
    elif num_gallons <= 22000:
        bill = 6 * num_gallons / 1000
    elif num_gallons <= 30000:
        bill = 7 * num_gallons / 1000
    else:
        bill = 10 * num_gallons / 1000
    return bill
""")
    
class GetPhoneBill(FunctionProblem):
    _var = 'get_phone_bill'
    _test_cases = [(5 + .5*i, get_phone_bill(5 + .5*i)) for i in range (0, 35)]
    _hint = """
あなたの解答は次のようなコードになるはずです：
```python
def get_phone_bill(gb):
    if gb <= 15:
        bill = ____
    else:
        bill = 100 + ____
    return bill
```
"""
    _solution = CS(
"""def get_phone_bill(gb):
    if gb <= 15:
        bill = 100
    else:
        bill = 100 + (gb - 15) * 100
    return bill
""")

class GetLabels(CodingProblem):
    _congrats = "すべての食品にラベルを付けることができたら、次のチュートリアルに進む準備ができています！"
    _correct_message = ""
    def check(self):
        pass

qnames = list(bind_exercises(globals(), [
    GetGrade,
    CostProjectPartDeux,
    GetWaterBill,
    GetPhoneBill,
    GetLabels
], var_format='q{n}'))

from learntools.core import binder
for name in qnames:
    globals()[name].globals = binder.readonly_globals()

__all__ = qnames
