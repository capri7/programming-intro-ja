from learntools.core import *

def get_expected_cost(beds, baths, has_basement):
    value = 80000 + 30000 * beds + 10000 * baths + 40000 * has_basement
    return value

class FloatToInt(ThoughtExperiment):
    _solution = ("Python の `int()` 関数は、小数点以下を常に切り捨てて、0 に近づけるように整数に変換します。"
                 "たとえば、`int(2.9)` や `int(2.1)` はどちらも `2` に、`int(-1.1)` や `int(-1.9)` はどちらも `-1` になります。")


class MultiplyBooleans(ThoughtExperiment):
    _solution = (
        "`True` や `False` は、Python ではそれぞれ `1` と `0` として扱われます。"
        "そのため、数値や文字列にブール値を掛けると、次のような結果になります。\n\n"
        "- 数値 × `True` → 元の数値と同じ（1回分の計算）\n"
        "- 数値 × `False` → `0`（0回分の計算）\n"
        "- 文字列 × `True` → 元の文字列（1回繰り返し）\n"
        "- 文字列 × `False` → 空文字列（0回繰り返し）\n\n"
        "たとえば、`3 * True` は `3`、`'abc' * False` は `''` になります。"
    )


class EstimateHouseValueBool(FunctionProblem):
    _var = 'get_expected_cost'
    _test_cases = [
        ((1, 1, False), 120000),
        ((2, 1, True), 190000),
        ((3, 2, True), 230000),
        ((4, 5, False), 250000),
    ]
    _hint = (
        "`has_basement` は `True` または `False` のブール値です。\n"
        "`True` は 1、`False` は 0 として扱われるので、\n"
        "`40000 * has_basement` は、地下室があるときは 40000、ないときは 0 になります。\n\n"
        "（前の問題で学んだ「ブール値と数値の掛け算」のしくみを思い出してみましょう）"
    )
    _solution = CS(
"""# 寝室、浴室、地下室の有無から、想定価格を計算する関数です
def get_expected_cost(beds, baths, has_basement):
    # 基本料金は 80000 ドル
    # 寝室ごとに 30000 ドル、浴室ごとに 10000 ドルを追加
    # 地下室がある場合は 40000 ドルを追加（True → 1、False → 0 として計算）
    value = 80000 + 30000 * beds + 10000 * baths + 40000 * has_basement
    return value
""")


class AddingBooleans(ThoughtExperiment):
    _solution = (
        "Pythonでは、ブール値 `True` と `False` は、それぞれ `1` と `0` として扱われます。\n"
        "そのため、ブール値を数値と一緒に加算すると、次のように動作します：\n\n"
        "- `True + 3` → `4`（1 を足したことになる）\n"
        "- `False + 7` → `7`（0 を足したことになる）\n\n"
        "つまり、`True` は 1、`False` は 0 として計算されるということです。"
    )


class CustomEngravings(FunctionProblem):
    _var = 'cost_of_project'
    _test_cases = [
        (("Charlie+Denver", True), 240),
        (("08/10/2000", False), 120),
        (("Adrian", True), 160),
        (("Ana", False), 71),
    ]
    _hint = (
        "この問題では、プロジェクトに純金（solid_gold）を使うかどうかで、価格が変わります。\n\n"
        "- `solid_gold = True` のときは、純金価格を使う\n"
        "- `solid_gold = False` のときは、通常の価格を使う\n\n"
        "この条件をPythonで表すには、次のような式が使えます：\n"
        "`cost = solid_gold * 純金価格 + (not solid_gold) * 通常価格`\n\n"
        "`True` は `1` として、`False` は `0` として扱われることを思い出してください。\n"
        "そのため、純金の場合は `(1 * 純金価格 + 0 * 通常価格)`、\n"
        "通常の場合は `(0 * 純金価格 + 1 * 通常価格)` となり、適切な価格だけが加算されます。\n\n"
        "どの価格をどこに入れるべきか、じっくり考えてみましょう。"
    )
    _solution = CS(
"""# プロジェクトの刻印文字列と、純金を使うかどうかを元に、価格を計算します
def cost_of_project(engraving, solid_gold):
    # 条件によって価格の計算方法が異なります
    # 純金の場合: 基本料金100 + 1文字ごとに10ドル
    # 通常素材の場合: 基本料金50 + 1文字ごとに7ドル

    # solid_gold が True のとき: 純金の価格が使われる（False の項は 0 になる）
    # solid_gold が False のとき: 通常の価格が使われる（True の項は 0 になる）
    cost = solid_gold * (100 + 10 * len(engraving)) + (not solid_gold) * (50 + 7 * len(engraving))

    return cost
""")

class CustomEngravingsWithBonus(FunctionProblem):
    _var = 'cost_of_project_v2'
    _test_cases = [
        (("Hello there!", False), 50 + 7 * len("Hello there!")),         # 文字数 12 → 追加なし
        (("Custom engraving long", True), 100 + 10 * len("Custom engraving long") + 25),  # 21文字 → 追加あり
        (("12345678901234567890", False), 50 + 7 * 20),                   # 20文字 → 追加なし
        (("A really really long engraving!", True), 100 + 10 * len("A really really long engraving!") + 25), # 長文
    ]

    _hint = (
        "まず、基本の費用は `solid_gold` に応じて 50 または 100 に、1文字あたり 7 または 10 を加えたものになります。\n"
        "さらに、`engraving` の長さが 20 を超える場合には、追加料金として 25 ドルを加算します。\n\n"
        "ヒント：長さが 20 を超えているかを判断するには `len(engraving) > 20` を使いましょう。\n"
        "その結果は `True` または `False` になりますので、ブール値を使って 25 を掛け算する方法も使えます。"
    )

    _solution = CS(
"""def cost_of_project_v2(engraving, solid_gold):
    base_cost = solid_gold * (100 + 10 * len(engraving)) + (not solid_gold) * (50 + 7 * len(engraving))
    extra_charge = 25 * (len(engraving) > 20)
    return base_cost + extra_charge
""")


qnames = list(bind_exercises(globals(), [
    FloatToInt,
    MultiplyBooleans,
    EstimateHouseValueBool,
    AddingBooleans,
    CustomEngravings,
    CustomEngravingsWithBonus
], var_format='q{n}'))

from learntools.core import binder
for name in qnames:
    globals()[name].globals = binder.readonly_globals()

__all__ = qnames
