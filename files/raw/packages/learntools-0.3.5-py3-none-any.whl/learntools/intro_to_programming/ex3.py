from learntools.core import *

def get_expected_cost(beds, baths, has_basement):
    value = 80000 + 30000 * beds + 10000 * baths + 40000 * has_basement
    return value

class FloatToInt(ThoughtExperiment):
    _solution = ("負の浮動小数点数は、常に最も近い整数に切り上げられます（例えば、"
                 "-1.1 と -1.9 はどちらも -1 に切り上げられます）。正の浮動小数点数は、"
                 "常に最も近い整数に切り捨てられます（例えば、2.1 と 2.9 はどちらも 2 に切り捨てられます）。")
    
class MultiplyBooleans(ThoughtExperiment):
    _solution = ("整数や浮動小数点数を、`True` の値を持つブール値で掛けると、その整数や浮動小数点数がそのまま返されます（1を掛けるのと同じです）。"
                 "整数や浮動小数点数を、`False` の値を持つブール値で掛けると、常に0が返されます。これは、正の数でも負の数でも同じです。"
                 "文字列を、`True` の値を持つブール値で掛けると、その文字列がそのまま返されます。"
                 "そして、文字列を、`False` の値を持つブール値で掛けると、空の文字列（または長さが0の文字列）が返されます。")

class EstimateHouseValueBool(FunctionProblem):
    _var = 'get_expected_cost'
    _test_cases = [
        ((1, 1, False), 120000),
        ((2, 1, True), 190000),
        ((3, 2, True), 230000),
        ((4, 5, False), 250000),
    ]
    _hint = ("変数 `has_basement` は `True` または `False` です。これを40000（地下室の価値）と掛け算するとどうなりますか？"
             "わからない場合は、前の問題を参考にしてください。")
    _solution = CS(
"""def get_expected_cost(beds, baths, has_basement):
    value = 80000 + 30000 * beds + 10000 * baths + 40000 * has_basement
    return value
""")

class AddingBooleans(ThoughtExperiment):
    _solution = "ブール値を加算するとき、`False` を加えることは 0 を加えることと同じで、`True` を加えることは 1 を加えることと同じです。"
    
class CustomEngravings(FunctionProblem):
    _var = 'cost_of_project'
    _test_cases = [
        (("Charlie+Denver", True), 240),
        (("08/10/2000", False), 120),
        (("Adrian", True), 160),
        (("Ana", False), 71),
    ]
    _hint = ("このプロジェクトには2つの選択肢があります - プロジェクトが純金を使用するかどうかです。これを考慮して、次のように解決策を構築できます: `cost = solid_gold * ____ + (not solid_gold) * ____`。空欄に何を入れるべきかを考えてみましょう。また、次のことを覚えておいてください：\n"
             "- `solid_gold = True` の場合、`(not solid_gold) = False` となり、`solid_gold = False` の場合、`(not solid_gold) = True` となります。\n"
             "- 整数に `True` を掛けることは 1 を掛けることと同じで、整数に `False` を掛けることは 0 を掛けることと同じです。")
    _solution = CS(
"""def cost_of_project(engraving, solid_gold):
    cost = solid_gold * (100 + 10 * len(engraving)) + (not solid_gold) * (50 + 7 * len(engraving))
    return cost
""")


qnames = list(bind_exercises(globals(), [
    FloatToInt,
    MultiplyBooleans,
    EstimateHouseValueBool,
    AddingBooleans,
    CustomEngravings
], var_format='q{n}'))

from learntools.core import binder
for name in qnames:
    globals()[name].globals = binder.readonly_globals()

__all__ = qnames
