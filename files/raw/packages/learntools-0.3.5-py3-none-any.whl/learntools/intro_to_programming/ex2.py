from learntools.core import *
import math

def get_expected_cost(beds, baths):
    value = 80000 + 30000 * beds + 10000 * baths
    return value

def get_cost(sqft_walls, sqft_ceiling, sqft_per_gallon, cost_per_gallon):
    total_sqft = sqft_walls + sqft_ceiling
    gallons_needed = total_sqft / sqft_per_gallon
    cost = cost_per_gallon * gallons_needed
    return cost

class GetExpectedCost(FunctionProblem):
    _var = 'get_expected_cost'
    _test_cases = [
        ((0, 0), 80000),
        ((0, 1), 90000),
        ((1, 0), 110000),
        ((1, 1), 120000),
        ((1, 2), 130000),
        ((2, 3), 170000),
        ((3, 2), 190000),
        ((3, 3), 200000),
        ((3, 4), 210000),
    ]
    _hint = ("この値は、基本料金（`80000`）に、寝室の合計費用（`30000 * beds`）、 "
             "さらに浴室の合計費用（`10000 * baths`）を加えたものになります。")
    _solution = CS(
"""
def get_expected_cost(beds, baths):
    value = 80000 + 30000 * beds + 10000 * baths
    return value
""")
    
class RunGetExpectedCost(EqualityCheckProblem):
    _vars = ['option_one', 'option_two', 'option_three', 'option_four']
    _expected = [get_expected_cost(2, 3), get_expected_cost(3, 2), get_expected_cost(3, 3), get_expected_cost(3, 4)]
    _hint = ("もし `option_five` に、寝室が5部屋・浴室が3つある家の想定費用を代入したい場合は、"
             "`option_five = get_expected_cost(5, 3)` のように書きます。")
    _solution = CS(
"""# get_expected_cost 関数を使って、それぞれの値を埋めましょう
option_one = get_expected_cost(2, 3)
option_two = get_expected_cost(3, 2)
option_three = get_expected_cost(3, 3)
option_four = get_expected_cost(3, 4)
""")

class GetCostPaint(FunctionProblem):
    _var = 'get_cost'
    _test_cases = [
        ((432, 144, 400, 15), 21.599999999999998),
        ((400, 400, 400, 10), 20.0),
        ((400, 500, 300, 16), 48.0),
    ]
    _hint = ("まず、塗装が必要な面積（平方フィートの合計）を計算しましょう。"
         "その面積に基づいて、必要なペンキのガロン数を求めます。"
         "必要なガロン数がわかれば、プロジェクト全体の費用を計算できます。")
    _solution = CS(
"""
def get_cost(sqft_walls, sqft_ceiling, sqft_per_gallon, cost_per_gallon):
    total_sqft = sqft_walls + sqft_ceiling
    gallons_needed = total_sqft / sqft_per_gallon
    cost = cost_per_gallon * gallons_needed
    return cost
""") 
    
class GetCostPaintExample(EqualityCheckProblem):
    _var = 'project_cost'
    _expected = get_cost(432, 144, 400, 15)
    _hint = ("たとえば、壁が800平方フィート、天井が160平方フィートの部屋に1回塗装する場合を考えましょう。"
             "1ガロンのペンキで300平方フィートを塗ることができ、価格が10ドルの場合、"
             "`project_cost = get_cost(800, 160, 300, 10)` のように記述します。")
    _solution = CS(
"""# project_cost変数に、プロジェクトの費用を代入しましょう
project_cost = get_cost(432, 144, 400, 15) 
""")

class NoMoreFractions(FunctionProblem):
    _var = 'get_actual_cost'
    _test_cases = [
        ((432, 144, 400, 15), 30),
        ((400, 500, 400, 10), 30),
        ((400, 900, 300, 16), 80),
    ]
    _hint = ("まずは `get_cost()` 関数をベースに始めましょう。必要な変更はひとつだけ、"
             "購入するペンキのガロン数を切り上げるために `math.ceil()` を追加することです。"
             "関数のどこに追加すればよいか、考えてみましょう。")
    _solution = CS(
"""def get_actual_cost(sqft_walls, sqft_ceiling, sqft_per_gallon, cost_per_gallon):
    total_sqft = sqft_walls + sqft_ceiling
    gallons_needed = total_sqft / sqft_per_gallon
    gallons_to_buy = math.ceil(gallons_needed)
    cost = cost_per_gallon * gallons_to_buy
    return cost
""")


qnames = list(bind_exercises(globals(), [
    GetExpectedCost,
    RunGetExpectedCost,
    GetCostPaint,
    GetCostPaintExample,
    NoMoreFractions
], var_format='q{n}'))

from learntools.core import binder
for name in qnames:
    globals()[name].globals = binder.readonly_globals()

__all__ = qnames

