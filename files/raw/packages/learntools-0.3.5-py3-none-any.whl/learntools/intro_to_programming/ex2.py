from learntools.core import *
import math

def get_expected_cost(beds, baths):
    value = 80000 + 30000 * beds + 10000 * baths
    return value

def get_cost(sqft_walls, sqft_ceiling, sqft_per_gallon, cost_per_gallon):
    total_sqft = sqft_walls + sqft_ceiling
    gallons_needed = total_sqft / sqft_per_gallon
    cost = cost_per_gallon * gallons_needed
    return cost

class GetExpectedCost(FunctionProblem):
    _var = 'get_expected_cost'
    _test_cases = [
        ((0, 0), 80000),
        ((0, 1), 90000),
        ((1, 0), 110000),
        ((1, 1), 120000),
        ((1, 2), 130000),
        ((2, 3), 170000),
        ((3, 2), 190000),
        ((3, 3), 200000),
        ((3, 4), 210000),
    ]
    _hint = (
        "この関数では、以下の3つを合計して最終的な値を計算します：\n\n"
        "- 基本料金：80000\n"
        "- 寝室ごとの追加料金：30000 × 寝室の数（`beds`）\n"
        "- 浴室ごとの追加料金：10000 × 浴室の数（`baths`）"
    )
    _solution = CS(
"""
def get_expected_cost(beds, baths):
    value = 80000 + 30000 * beds + 10000 * baths
    return value
""")


class RunGetExpectedCost(EqualityCheckProblem):
    _vars = ['option_one', 'option_two', 'option_three', 'option_four']
    _expected = [get_expected_cost(2, 3), get_expected_cost(3, 2), get_expected_cost(3, 3), get_expected_cost(3, 4)]
    _hint = (
        "`get_expected_cost(beds, baths)` を使えば、どんな組み合わせの部屋数でも簡単に費用を計算できます。\n\n"
        "たとえば、寝室が 5 部屋・浴室が 3 つの家について計算したいなら、\n"
        "`option_five = get_expected_cost(5, 3)` と書けば OK です。"
    )
    _solution = CS(
"""# get_expected_cost 関数を使って、それぞれの値を埋めましょう
option_one = get_expected_cost(2, 3)
option_two = get_expected_cost(3, 2)
option_three = get_expected_cost(3, 3)
option_four = get_expected_cost(3, 4)
""")


class GetCostPaint(FunctionProblem):
    _var = 'get_cost'
    _test_cases = [
        ((432, 144, 400, 15), 21.599999999999998),
        ((400, 400, 400, 10), 20.0),
        ((400, 500, 300, 16), 48.0),
    ]
    _hint = (
        "この関数では、次の3ステップで計算を進めます：\n\n"
        "1. 壁と天井の面積を合計して、塗装が必要な総面積（平方フィート）を求めます。\n"
        "2. 1ガロンで何平方フィート塗れるかに基づいて、必要なペンキの量（ガロン数）を計算します。\n"
        "3. ガロン単価をかけて、最終的な費用を求めます。"
    )
    _solution = CS(
"""
def get_cost(sqft_walls, sqft_ceiling, sqft_per_gallon, cost_per_gallon):
    total_sqft = sqft_walls + sqft_ceiling
    gallons_needed = total_sqft / sqft_per_gallon
    cost = cost_per_gallon * gallons_needed
    return cost
""") 


class GetCostPaintExample(EqualityCheckProblem):
    _var = 'project_cost'
    _expected = get_cost(432, 144, 400, 15)
    _hint = (
        "関数 `get_cost()` は、壁と天井の面積、1ガロンあたりの塗装面積、1ガロンの価格を使って、\n"
        "塗装プロジェクトの費用を計算します。\n\n"
        "たとえば、壁が 800 平方フィート、天井が 160 平方フィート、\n"
        "1ガロンで 300 平方フィート塗ることができ、ペンキの価格が 10 ドルなら、\n"
        "`project_cost = get_cost(800, 160, 300, 10)` のように書くことができます。"
    )
    _solution = CS(
"""# project_cost変数に、プロジェクトの費用を代入しましょう
project_cost = get_cost(432, 144, 400, 15) 
""")


class NoMoreFractions(FunctionProblem):
    _var = 'get_actual_cost'
    _test_cases = [
        ((432, 144, 400, 15), 30),
        ((400, 500, 400, 10), 30),
        ((400, 900, 300, 16), 80),
    ]
    _hint = (
        "`get_cost()` 関数をベースにして考えましょう。\n\n"
        "今回の変更点はひとつだけです：\n"
        "**ペンキのガロン数を小数ではなく、切り上げて整数にする必要があります。**\n\n"
        "そのためには、`math.ceil()` を使って、ガロン数を丸めましょう。\n"
        "どの行に追加すればよいか、関数の流れを思い出しながら考えてみてください。"
    )
    _solution = CS(
"""def get_actual_cost(sqft_walls, sqft_ceiling, sqft_per_gallon, cost_per_gallon):
    total_sqft = sqft_walls + sqft_ceiling
    gallons_needed = total_sqft / sqft_per_gallon
    gallons_to_buy = math.ceil(gallons_needed)
    cost = cost_per_gallon * gallons_to_buy
    return cost
""")


# --- 演習問題のバインド処理（問題を q1, q2, ... に登録）---

qnames = list(bind_exercises(globals(), [
    GetExpectedCost,
    RunGetExpectedCost,
    GetCostPaint,
    GetCostPaintExample,
    NoMoreFractions
], var_format='q{n}'))


# --- 各問題に、読み取り専用のグローバル変数環境をバインド ---
from learntools.core import binder
for name in qnames:
    globals()[name].globals = binder.readonly_globals()

# --- エクスポート対象（__all__）に問題変数を登録 ---

__all__ = qnames

