from learntools.core import *


class AddThreeOrEight(FunctionProblem):
    _var = 'add_three_or_eight'
    _test_cases = [
        (5, 8),      # 5 < 10 → 5 + 3 = 8
        (9, 12),     # 9 < 10 → 9 + 3 = 12
        (10, 18),    # 10 >= 10 → 10 + 8 = 18
        (12, 20),    # 12 >= 10 → 12 + 8 = 20
    ]
    _hint = "10 未満かどうかを if 文でチェックし、条件に応じて 3 または 8 を加えましょう。"
    _solution = CS(
        """
def add_three_or_eight(number):
    if number < 10:
        result = number + 3
    else:
        result = number + 8
    return result
"""
    )


qnames = list(bind_exercises(globals(), [
    AddThreeOrEight
], var_format='q6a_{n}'))

from learntools.core import binder
for name in qnames:
    globals()[name].globals = binder.readonly_globals()

__all__ = qnames




