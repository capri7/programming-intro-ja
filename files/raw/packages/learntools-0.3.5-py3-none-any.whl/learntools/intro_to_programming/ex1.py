from learntools.core import *

num_years = 4
days_per_year = 365 
hours_per_day = 24
mins_per_hour = 60
secs_per_min = 60
births_per_min = 250

survived = 342
minors = 113
total = 891

class RunHelloWorld(CodingProblem):
    _congrats = ("「Hello, world!」と表示されていれば、"
                 "メッセージの出力に成功しています。"
                 "次の問題に進みましょう。")
    _correct_message = "正しく出力できました！"

    def check(self):
        pass

class PrintAnotherMsg(CodingProblem):
    _congrats = (
        "自分のメッセージが表示されたら準備完了です。"
        "次の問題に進みましょう。"
    )
    _correct_message = "出力できました！"

    def check(self):
        pass

class LearnCheckingCode(CodingProblem):
    _hint = "もし問題に行き詰まった場合は、解答を見る前にヒントの確認をお勧めします。"
    _solution = ("ヒントを確認し、チュートリアルを再度読み返してもまだ解決できない場合は、解答を表示することができます。"
                 "また、正しく答えた場合でも、公式の解答と異なるかどうかをチェックできます（正解が複数ある場合もあります）。")
    _congrats = "ヒントと解答を表示したら、次の問題に進む準備ができています。"
    _correct_message = "バッチリ表示できましたね！"
    def check(self):
        pass
    
class BirthsPerYear(EqualityCheckProblem):
    _vars = ['births_per_min', 'births_per_day']
    _expected = [250, births_per_min * mins_per_hour * hours_per_day]
    _hint = (
        "変数を使って、まず1日が何分かを計算しましょう。"
        "つぎに、1日が何分かがわかったら、1分あたりの出生数を掛ければ答えが出ます。"
    )
    _solution = CS(
"""# births_per_min変数に値を設定
births_per_min = 250

# births_per_day変数に値を設定（1日あたりの出生数を計算）
births_per_day = births_per_min * mins_per_hour * hours_per_day
"""
    )

class BonusTitanic(EqualityCheckProblem):
    _vars = ['survived_fraction', 'minors_fraction']
    _expected = [survived/total, minors/total]
    _hint = (
        "タイタニック号で生存した人の割合を求めるには、"
        "生存者数を全乗客数で割ります。"
        "この問題では `survived`、`total`、`minors` の変数を使ってください。"
    )
    _solution = CS(
"""# survived_fraction変数に生存者の割合を設定
survived_fraction = survived/total

# survived_fractionの値を表示
print(survived_fraction)

# minors_fraction変数に未成年者の割合を設定
minors_fraction = minors/total 

# minors_fractionの値を表示
print(minors_fraction)
"""
    )

qnames = list(bind_exercises(globals(), [
    RunHelloWorld,
    PrintAnotherMsg,
    LearnCheckingCode,
    BirthsPerYear,
    BonusTitanic
], var_format='q{n}'))

from learntools.core import binder
for name in qnames:
    globals()[name].globals = binder.readonly_globals()

__all__ = qnames


