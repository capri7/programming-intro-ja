from learntools.core import *

def excess_saturated_fat(saturated_fat_g, calories_per_serving):
    return (saturated_fat_g * 9 / calories_per_serving >= 0.1)

class ExcessSaturatedFat(FunctionProblem):
    _var = 'excess_saturated_fat'
    _test_cases = [((2, 100), True), ((0.5, 200), False)]
    _hint = "飽和脂肪1gあたり9カロリーです。計算式が正しくなるように条件式を組み立てましょう。"
    _solution = '''def excess_saturated_fat(saturated_fat_g, calories_per_serving):
    return (saturated_fat_g * 9 / calories_per_serving >= 0.1)'''



def excess_trans_fat(trans_fat_g, calories_per_serving):
    return (trans_fat_g * 9 / calories_per_serving >= 0.01)

class ExcessTransFat(FunctionProblem):
    _var = 'excess_trans_fat'
    _test_cases = [((0.5, 100), True), ((0.05, 200), False)]
    _hint = "トランス脂肪1gあたりも9カロリーです。"
    _solution = '''def excess_trans_fat(trans_fat_g, calories_per_serving):
    return (trans_fat_g * 9 / calories_per_serving >= 0.01)'''

def excess_sugar(sugars_g, calories_per_serving):
    return (sugars_g * 4 / calories_per_serving >= 0.1)

class ExcessSugar(FunctionProblem):
    _var = 'excess_sugar'
    _test_cases = [((10, 100), True), ((1, 200), False)]
    _hint = "糖分1gあたりは4カロリーです。割合が0.1（10%）を超えるかどうかを調べましょう。"
    _solution = '''def excess_sugar(sugars_g, calories_per_serving):
    return (sugars_g * 4 / calories_per_serving >= 0.1)'''

def excess_sodium(calories_per_serving, sodium_mg):
    if calories_per_serving == 0:
        return (sodium_mg >= 45)
    else:
        return (sodium_mg / calories_per_serving >= 1)

class ExcessSodium(FunctionProblem):
    _var = 'excess_sodium'
    _test_cases = [((0, 50), True), ((100, 90), False)]  # 45mg以上、または100calあたり1mg以上
    _hint = "カロリー0の食品の場合、塩分が45mg以上であるかを確認しましょう。それ以外はカロリーあたり1mgを超えるかをチェックします。"
    _solution = '''def excess_sodium(calories_per_serving, sodium_mg):
    if calories_per_serving == 0:
        return (sodium_mg >= 45)
    else:
        return (sodium_mg / calories_per_serving >= 1)'''

def excess_calories(food_type, calories_per_serving, serving_size):
    if food_type == "solid":
        return (calories_per_serving / serving_size * 100 >= 275)
    elif food_type == "liquid":
        return (calories_per_serving / serving_size * 100 >= 70)
    else:
        raise ValueError("food_type must be 'solid' or 'liquid'")

class ExcessCalories(FunctionProblem):
    _var = 'excess_calories'
    _test_cases = [(("solid", 300, 100), True), (("liquid", 80, 100), False)]  # 固形物・液体のテストケース
    _hint = "固形食品は100gあたり275カロリー以上、液体食品は100gあたり70カロリー以上であれば超過です。"
    _solution = '''def excess_calories(food_type, calories_per_serving, serving_size):
    if food_type == "solid":
        return (calories_per_serving / serving_size * 100 >= 275)
    elif food_type == "liquid":
        return (calories_per_serving / serving_size * 100 >= 70)
    else:
        raise ValueError("food_type must be 'solid' or 'liquid'")'''

qnames = list(bind_exercises(globals(), [
    ExcessSaturatedFat,
    ExcessTransFat,
    ExcessSugar,
    ExcessSodium,
    ExcessCalories
], var_format='q{n}'))

from learntools.core import binder
for name in qnames:
    globals()[name].globals = binder.readonly_globals()

__all__ = qnames
