from learntools.core import *


def excess_saturated_fat(saturated_fat_g, calories_per_serving):
    return (saturated_fat_g * 9 / calories_per_serving >= 0.1)

class ExcessSaturatedFat(FunctionProblem):
    _var = 'excess_saturated_fat'
    _test_cases = [((2, 100), True), ((0.5, 200), False)]
    _hint = (
    "飽和脂肪1gには9カロリーあります。\n"
    "「飽和脂肪によるカロリーの割合」が 10% 以上なら `True` を返し、"
    "そうでなければ `False` を返す関数を作りましょう。\n\n"
    "式としては次のような形になります：\n"
    "`(saturated_fat_g * 9 / calories_per_serving) >= 0.1`"
    )
    _solution = '''def excess_saturated_fat(saturated_fat_g, calories_per_serving):
    return (saturated_fat_g * 9 / calories_per_serving >= 0.1)'''


def excess_trans_fat(trans_fat_g, calories_per_serving):
    return (trans_fat_g * 9 / calories_per_serving >= 0.01)

class ExcessTransFat(FunctionProblem):
    _var = 'excess_trans_fat'
    _test_cases = [((0.5, 100), True), ((0.05, 200), False)]
    _hint = "トランス脂肪1gあたりも9カロリーです。"
    _solution = '''def excess_trans_fat(trans_fat_g, calories_per_serving):
    return (trans_fat_g * 9 / calories_per_serving >= 0.01)'''


def excess_sugar(sugars_g, calories_per_serving):
    return (sugars_g * 4 / calories_per_serving >= 0.1)

class ExcessSugar(FunctionProblem):
    _var = 'excess_sugar'
    _test_cases = [((10, 100), True), ((1, 200), False)]
    _hint = "糖分1gあたりは4カロリーです。割合が0.1（10%）を超えるかどうかを調べましょう。"
    _solution = '''def excess_sugar(sugars_g, calories_per_serving):
    return (sugars_g * 4 / calories_per_serving >= 0.1)'''


def excess_sodium(calories_per_serving, sodium_mg):
    if calories_per_serving == 0:
        return (sodium_mg >= 45)
    else:
        return (sodium_mg / calories_per_serving >= 1)

class ExcessSodium(FunctionProblem):
    _var = 'excess_sodium'
    _test_cases = [((0, 50), True), ((100, 90), False)]  # 45mg以上、または100calあたり1mg以上
    _hint = (
        "この関数では、食品のカロリーとナトリウム量に応じて\n"
        "塩分の基準を満たすかどうかを判断します。\n\n"
        "- カロリーが0の場合は、ナトリウムが45mg以上であれば `True` を返します。\n"
        "- それ以外の場合は、「カロリー1kcalあたり1mg以上」の塩分を含む場合に `True` を返します。\n\n"
        "条件分岐には `if` / `else` を使いましょう。"
    )
    _solution = '''def excess_sodium(calories_per_serving, sodium_mg):
    if calories_per_serving == 0:
        return (sodium_mg >= 45)
    else:
        return (sodium_mg / calories_per_serving >= 1)'''


def excess_calories(food_type, calories_per_serving, serving_size):
    if food_type == "solid":
        return (calories_per_serving / serving_size * 100 >= 275)
    elif food_type == "liquid":
        return (calories_per_serving / serving_size * 100 >= 70)
    else:
        raise ValueError("food_type must be 'solid' or 'liquid'")

class ExcessCalories(FunctionProblem):
    _var = 'excess_calories'
    _test_cases = [(("solid", 300, 100), True), (("liquid", 80, 100), False)]  # 固形物・液体のテストケース
    _hint = (
    "この関数では、食品の種類ごとに基準を変えてカロリー超過かどうかを判定します。\n\n"
    "- 固形食品（'solid'）は 100g あたり 275kcal 以上で超過。\n"
    "- 液体食品（'liquid'）は 100g あたり 70kcal 以上で超過です。\n\n"
    "`calories_per_serving` を `serving_size` で割り、100倍することで「100g あたりのカロリー」に換算できます。\n"
    "適切な条件式を `if` 文で使い分けましょう。"
    )
    _solution = '''def excess_calories(food_type, calories_per_serving, serving_size):
    if food_type == "solid":
        return (calories_per_serving / serving_size * 100 >= 275)
    elif food_type == "liquid":
        return (calories_per_serving / serving_size * 100 >= 70)
    else:
        raise ValueError("food_type must be 'solid' or 'liquid'")'''
    


qnames = list(bind_exercises(globals(), [
    ExcessSaturatedFat,
    ExcessTransFat,
    ExcessSugar,
    ExcessSodium,
    ExcessCalories
], var_format='q5a_{n}'))

from learntools.core import binder
for name in qnames:
    globals()[name].globals = binder.readonly_globals()

__all__ = qnames



