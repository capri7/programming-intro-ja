"""
Problem.checkの実装で使用されるアサーション補助関数。

これらは主にEqualityCheckProblemで使用されます。エラーメッセージが分かりやすいため、
CodingProblemsのチェックメソッドで使用することができますが、
このコメントが書かれた2019年12月時点では、あまり広く使われていませんでした。
"""

import os
import numbers
import math
import functools
import logging

import pandas as pd
import numpy as np

def name_or_var(assert_fn):
    """
    このデコレーターが付けられたアサーション補助関数は、"name" 引数を受け取ります。
    これは、実際にチェックしている値を説明するマークダウン形式の文字列です。
    例えば、"dataframe"のような一般的な名前、"the result of calling `circle_area`"のような説明的な文、
    またはバックティックで囲まれた変数名である可能性があります。

    「バックティックで囲まれた変数名」のケースは非常に一般的であるため、
    このデコレーターは関数にオプションの「var」キーワード引数を追加します。
    var="foo"を渡すことは、name="foo"を渡すための簡便な省略形です。
    （「var」に値を渡す場合は、「name」に値を渡さないでください。）


    例:

    @name_or_var
    def assert_negative(actual, name):
        assert actual < 0, "{} は負の値であるべきですが、実際は {}".format(name, actual)

    # 以下はすべて有効な呼び出しです
    assert_negative(x, "銀行残高")
    assert_negative(x, name="`Bank.balance` 属性")
    assert_negative(x, var="bank_balance")  # assert_negative(x, "`bank_balance`") と同等
    """
    @functools.wraps(assert_fn)
    def wrapped(*args, **kwargs):
        var = kwargs.pop('var', None)
        if var:
            if 'name' in kwargs:
                logging.warning("関数 {} がキーワード引数 'name' と 'var' の両方を受け取りました。元々の 'name' の引数は上書きされます。".format(
                    assert_fn.__name__))
            kwargs['name'] = '`{}`'.format(var)
        return assert_fn(*args, **kwargs)
    return wrapped

@name_or_var
def assert_equal(actual, expected, name, failure_factory=None):
    """learntoolsのチェック処理における用途に特化した、多様なケースに対応可能な等価性を検証します。 
    EqualityCheckProblemのサブクラスは、最終的にこの関数をcheck メソッド内で使用します。

    この関数には、Pandasオブジェクト、ndarray、float など、いくつかの型の期待値に対する
    特別な処理が含まれています。
    """
    # 通常は == 演算子による比較を行いますが、一部のデータ型については特別な処理を行います
    if isinstance(expected, float):
        assert isinstance(actual, numbers.Number), \
        "変数 {} には数値が期待されていましたが、実際には `{!r}`（型 = `{}`）が渡されました。".format(
            name, actual, type(actual).__name__)    
        # float の比較には、相対誤差 1e-06 を許容する isclose を使用します。
        check = math.isclose(actual, expected, rel_tol=1e-06)
    elif isinstance(expected, pd.DataFrame):
        assert_df_equals(actual, expected, name)
        return
    elif isinstance(expected, pd.Series):
        assert_series_equals(actual, expected, name)
        return
    elif isinstance(actual, np.ndarray) or isinstance(expected, np.ndarray):
        check = np.array_equal(actual, expected)
    else:
        check = actual == expected
    
    if failure_factory:
        # このオプションのキーワード引数を使うと、
        # 呼び出し元が独自のエラーメッセージを生成する関数を渡すことができます。
        # 現在のところ、これは Python の ex1（好きな色を選ぶ問題）でのみ使用されています。
        _failure_message = failure_factory(name, actual, expected)
    else:
        # デフォルトのエラーメッセージを設定します。
        _failure_message = "変数 {} の値が正しくありません: `{}`".format(
                name, repr(actual))

    # 比較チェックに失敗した場合は、上で定義されたエラーメッセージを表示します。
    assert check, _failure_message

@name_or_var
def assert_has_columns(df, cols, name="dataframe", strict=False):
    """指定されたデータフレームが、指定された名前の列を含んでいることを確認します。
    `strict=True` の場合は、指定された列だけを持っていることも確認します。
    """
    for col in cols:
        # 各列がデータフレームに存在するかを確認します。
        assert col in df.columns, "{} に `{}` という列が存在することが期待されていました。".format(
                name, col
        )
    if strict:
        for col in df.columns:
            # strict モードでは、余分な列が含まれていないことも確認します。
            msg = "{} に予期しない列が含まれています: `{}`".format(name, col)
            assert col in cols, msg

@name_or_var
def assert_isinstance(cls, actual, name):
    # `actual` が指定された型 `cls` のインスタンスであることを確認します。
    # そうでない場合は、エラーメッセージを表示します。
    assert isinstance(actual, cls), "{} には型 `{!r}` が期待されていましたが、実際の型は `{!r}` でした。".format(name, cls, type(actual))

@name_or_var
def assert_is_one_of(actual, options, name):
    # `actual` の値が `options` の中のいずれかと一致するかを確認します。
    msg = "{} の値が正しくありません: `{!r}`".format(name, actual)
    assert actual in options, msg

@name_or_var
def assert_len(thing, exp_len, name):
    """指定されたオブジェクトの長さが、期待される長さと一致することを確認します。

    前提条件：対象オブジェクトが __len__ を実装していること
    """
    actual = len(thing)
    assert actual == exp_len, "{} の長さとして {} が期待されていましたが、実際は {} でした。".format(
            name, exp_len, actual,
            )

def assert_file_exists(path):
    # パスにスラッシュが含まれていれば「パス」、含まれていなければ「名前」として扱います。
    if '/' in path:
        pp = 'at path'
    else:
        pp = 'with name'
    
    # ファイルが存在することを確認します（存在しなければエラー）。
    msg = "指定されたファイルが {} `{}` に存在することが期待されていました。".format(pp, path)
    assert os.path.exists(path), msg

    # 対象が「ファイル」であることを確認します（ディレクトリなどであってはならない）。
    assert os.path.isfile(path), "`{}` はファイルである必要があります。".format(path)

@name_or_var
def assert_df_equals(actual, exp, name="dataframe"):
    # `actual` が pandas の DataFrame 型であることを確認します。
    assert_isinstance(pd.DataFrame, actual, name)

    # 行数（長さ）が一致していることを確認します。
    assert len(actual) == len(exp), "{} の行数として {} が期待されていましたが、実際は {} 行でした。".format(
        name, len(exp), len(actual))

    # 最初の n 行のみを比較して一致を確認します。
    # データフレームが数十万行ある場合はすべてを比較すると遅くなるためです。
    # ※この方法にはリスクもありますが、誤判定の可能性は低いと考えられます。
    lim = 100
    actual_sub = actual.head(lim)
    exp_sub = exp.head(lim)
    eq = actual_sub.equals(exp_sub)

    if eq:
        return  # 最初の100行が一致していれば、それで合格とします。
    # 一致していなかった場合、どこが異なるのかを明確に伝えるメッセージを用意したいところです。
    # TODO: 既にこのような比較処理を提供するライブラリが存在するかもしれません。
    #       ユニットテスト用途などでは非常に便利になるはずです。
    # 列名が一致しているか、かつ余計な列が含まれていないかを検証します。
    assert_has_columns(actual, exp.columns, name, strict=True)
    # TODO:
    # - インデックスが一致しているかをチェックする？
    # - 列ごとに値の一致を確認する？
    # - 各列のデータ型（dtype）が一致しているかを確認する？
    #
    # DataFrame.equals() はこれらすべてをチェックしますが、
    # 一部のケースでは厳しすぎることもあります。
    # たとえば、期待値が [1, 2, 3]、実際の値が [1., 2., 3.] のような場合は、
    # dtype の違いを気にしなくていいかもしれません。

    # 最終的に、不一致と判定された場合は汎用的なエラーメッセージを表示します。
    assert False, "{} の値が正しくありません".format(name)

@name_or_var
def assert_series_equals(actual, exp, name="series"):
    # actual が pandas の Series 型であることを確認します。
    assert_isinstance(pd.Series, actual, name=name)

    # Series の長さが一致していることを確認します。
    assert len(actual) == len(exp), "{} の長さとして {} が期待されていましたが、実際は {} でした。".format(
        name, len(exp), len(actual))

    # 最初の100件のみで一致確認を行います（大量データの場合の高速化のため）
    lim = 100
    actual_sub = actual.head(lim)
    exp_sub = exp.head(lim)
    eq = actual_sub.equals(exp_sub)

    if eq:
        return  # 最初の100件が一致していれば、合格とします。

    # TODO: より詳細なチェックを追加する予定
    assert False, "{} の値が正しくありません".format(name)


# from learntools.core.asserts import * としたときに、
# assert で始まる関数名だけがインポートされるようにします（ヘルパー関数群）
__all__ = [name for name in dir() if name.startswith('assert')]
