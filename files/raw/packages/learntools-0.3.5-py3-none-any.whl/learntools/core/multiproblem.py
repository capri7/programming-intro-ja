class MultipartProblem:
    """複数の関連する問題（Problem）をひとつの問題としてまとめて扱うためのコンテナです。
    たとえば、q1 が MultipartProblem（MPP）の場合、その小問には q1.a、q1.b のようにアクセスできます。
    """
    def __init__(self, *probs):
        self.problems = probs
        # 文字列識別子（例：'a'、'b' など）から ProblemView への対応関係を保持するマッピング
        self._prob_map = {}

    def _repr_markdown_(self):
        return repr(self)

    def __repr__(self):
        varname = self._varname
        part_names = ['`{}.{}`'.format(varname, letter) for letter in self._prob_map]
        return """この問題は {} 個のパートに分かれています。それぞれのパートには次のようにアクセスできます: {}。
たとえば、パート a のヒントを得るには `{}.a.hint()` と入力します。""".format(
            len(self._prob_map), ', '.join(part_names), varname
        )




