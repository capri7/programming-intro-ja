from . import colors

def colorify(text, color):
    return '<span style="color:{}">{}</span>'.format(color, text)

class RichText:
    """このクラスは、リッチな表現とプレーンテキストの両方に対応するメソッドを定義しています。

    コードセルから表示された場合には、見栄えの良いリッチな出力として表示されます。
    一方、コンソール上ではシンプルなテキスト表示にフォールバックされます。
    """
    def __init__(self, txt, color=None, **kwargs):
        self.txt = txt
        self.color = color
        self.kwargs = kwargs

    def _repr_markdown_(self):
        if self.color:
            return colorify(self.txt, self.color)
        return self.txt

    def __repr__(self):
        return self.txt

class PrefixedRichText(RichText):
    """先頭にラベル（必要に応じて別の色で装飾可能）を付けた RichText メッセージです。"""

    label_color = 'black' # これは任意の有効な CSS カラーで上書きできます
    @property
    def label(self):
        # _label 属性が存在しない場合は、クラス名を代わりに使用します
        if hasattr(self, '_label'):
            return self._label
        return self.__class__.__name__

    def _repr_markdown_(self):
        if not self.txt:
           return colorify(self.label, self.label_color)
        pre = colorify(self.label+':', self.label_color)
        return pre + ' ' + self.txt

    def __repr__(self):
        if not self.txt:
            return self.label
        return self.label + ':' + ' ' + self.txt

class Hint(PrefixedRichText):
    label_color = colors.HINT
    def __init__(self, txt, n=1, last=True):
        self.n = n
        # これは複数ヒントのうちの1つですか？
        self.is_multi = n > 1 or not last
        if not last:
            # TODO: ProblemViewに関連付けられた実際の名前（例：`q2.hint(2)`）を参照できると便利かもしれません
            coda = '\n(さらにヒントを見るには `.hint({})` を呼び出します)'.format(n+1)
            txt += coda
        super().__init__(txt)

    @property
    def label(self):
        if self.is_multi:
            return 'ヒント {}'.format(self.n)
        return 'ヒント'

class Correct(PrefixedRichText):
    @property
    def _label(self):
        return self.kwargs.get('_congrats', '正解')
    label_color = colors.CORRECT

class Solution(PrefixedRichText):
    label_color = colors.SOLUTION
    _label = '解答'

class CodeSolution(Solution):
    """Python コードのみで構成された解答です。これを構文ハイライトされたコードブロックとして表示します。"""

    _label = '解答'

    def __init__(self, *lines):
        """利便性のために、1つの複数行文字列ではなく、コードの各行を1つずつ別々の文字列として渡すことができます。"""
    
        txt = '\n'.join(lines)  # 行を改行で結合
        wrapped = "\n```python\n{}\n```".format(txt)  # コードブロックとしてマークダウン形式で整形
        super().__init__(wrapped)  # 親クラスに渡す

    @classmethod
    def load(cls, path):
        """指定されたパスのソースファイル内のコードを読み込み、それを含む CodeSolution インスタンスを返します。"""
        
        with open(path) as f:
            lines = f.readlines()
            # 各行の末尾の改行を削除（コンストラクタで改行を再追加するため）
            lines = [line[:-1] for line in lines
                     # 小手先の対応：特定の import 行は除外
                     if not line.startswith('from learntools.python.solns')
                     ]
            return cls(*lines)

class TestFailure(PrefixedRichText):
    label_color = colors.INCORRECT
    _label = '不正解'

class ProblemStatement(PrefixedRichText):
    label_color = colors.INFO
    _label = '確認'
