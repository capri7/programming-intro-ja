"""
learntools.core は、演習モジュールで通常必要とされるコアサブパッケージのすべてのコンテンツをエクスポートします。
例えば、`Problem` サブクラスを継承するためのクラス、カスタム `check()` メソッドから呼び出すためのアサート関数、`_solution` 属性をラップするための `CodeSolution` クラス（便宜上、略して `CS` としてエイリアスされます）などです。

ほとんどの演習モジュールでは、`from learntools.core import *` を使えば、必要なすべての機能が含まれることになります。
"""

# これは演習モジュール内では使用されませんが、演習ノートブックが
# "from learntools.core import binder" で始められるように、ここでエクスポートしています。
from learntools.core.globals_binder import binder

# すべての演習モジュールは、このヘルパー関数の呼び出しで締めくくられます
from learntools.core.utils import bind_exercises
# Problem クラスおよびそのサブクラス（例： EqualityCheckProblem, ThoughtExperiment)
from learntools.core.problem import *
from learntools.core.multiproblem import MultipartProblem
# 非常に頻繁に使用されるため、短いエイリアスを付ける価値があります。
from learntools.core.richtext import CodeSolution as CS
# アサートヘルパー関数は問題のサブクラスでのカスタム check メソッドでよく使用されます
from learntools.core.asserts import *

# ユーザーが変数 foo に値を設定する演習のスターターコードでは、
# `foo = __` で始めさせます。
from learntools.core.constants import PLACEHOLDER as ____

# 少し不正規ですが、演習モジュールが `from learntools.core import *` を使用した際に
# '____' がインポートされるようにしたいのです。デフォルトでは、アンダースコアで始まる名前は
# スターインポートでインポートされません。
__all__ = [name for name in dir() if not name.startswith('_')] + ['____']



