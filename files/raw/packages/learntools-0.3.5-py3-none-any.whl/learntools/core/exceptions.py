
class NotAttempted(Exception):
    pass

class Incorrect(Exception):
    pass

class UserlandExceptionIncorrect(Incorrect):
    """ユーザーの解答が不正である理由として、関数を呼び出した際に予期しない例外が発生した場合に表示します。
    """
    def __init__(self, exception, args):
        self.wrapped_exception = exception
        self.msg  = ("引数 `{!r}` で関数を呼び出した際に、Pythonは次の例外を発生させました... **`{}: {}`**").format(
                        args, exception.__class__.__name__, exception)
    def __str__(self):
        return self.msg

class Uncheckable(Exception):
    pass
