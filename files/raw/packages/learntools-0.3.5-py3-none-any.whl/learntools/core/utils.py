from learntools.core.multiproblem import MultipartProblem

def backtickify(s):
    return '`{}`'.format(s)

# これは、追加のボーナス問題を扱っていた時代の名残で、現在はもう必要のない
# スコアリングメカニズムのオプションです
quantum_of_bonus = 1/37

def instantiate_probview(prob_cls, value_per_problem):
    # TODO: 環境をインポートする
    from learntools.core import problem_view as pv
    from learntools.core.globals_binder import binder
    # 注: 将来的にはこのクラスにサブクラスが追加されるかもしれません？
    viewer_cls = pv.ProblemView
    prob = prob_cls()
    if prob._counts_for_points:
        if prob._bonus:
            prob.point_value = quantum_of_bonus
        else:
            prob.point_value = value_per_problem

    else:
        prob.point_value = 0
    view = viewer_cls(prob, binder.readonly_globals())
    # XXX: 循環参照。 :/
    # weakref を使うことを検討してください。 (https://docs.python.org/3/library/weakref.html)
    # また、これらの抽象化の間にもう少しクリーンな分離があれば良かったのですが...
    prob._view = view
    return view

def bind_exercises(g, exercises, start=1, var_format='q{n}'):
    """演習モジュールの globals() 辞書と順序付けられた Problem サブクラスのリストを基に、
    問題のインスタンス化（厳密には ProblemView インスタンスでラップされたもの）を参照する変数の
    シーケンスを作成します（デフォルトでは q1, q2, q3... ですが、start と var_format のキーワード引数
    によってカスタマイズ可能です）。
    これらの変数割り当てを与えられたplaceholderの空間に埋め込み、すべての新しい変数の名前を返します。

    exercises の要素はプレースホルダーとして None である場合もあり、その場合は対応する変数がスキップされます。
    例：[SpamProblem, None, EggsProblem] は、変数 q1 と q3 を生成します。
    """
    denom = sum( 
            (getattr(prob, '_counts_for_points', False) and not prob._bonus) 
            for prob in exercises
            )
    try:
        value_per_problem = 1 / denom
    except ZeroDivisionError:
        value_per_problem = 1.0

    for i, prob_cls in enumerate(exercises):
        # None の値はプレースホルダーです。対応する問題番号を予約しますが、対応する Problem オブジェクトは作成しません。
        if prob_cls is None:
            continue
        qno = i + start
        varname = var_format.format(n=qno)
        assert varname not in g
        # TODO: おそらく、これらをサブリストとして渡す方がクリーンです。MultipartProblem クラスが初期状態で開始し、ここで「アクティブ化」されるのではなく。
        if isinstance(prob_cls, MultipartProblem):
            mpp = prob_cls
            g[varname] = mpp
            mpp._varname = varname
            for j, prob_cls in enumerate(mpp.problems):
                prob = instantiate_probview(prob_cls, value_per_problem)
                # クラスの外で即席で追加されたプロパティがさらに増えた…
                prob._order = '{}.{}'.format(qno, j+1)
                letter = chr(ord('a')+j)
                setattr(mpp, letter, prob)
                mpp._prob_map[letter] = prob
        else:
            pv = instantiate_probview(prob_cls, value_per_problem)
            pv._order = str(qno)
            g[varname] = pv
        yield varname
    # 問題の分離が不十分ですが、とにかく、演習モジュールは quad エイリアス変数をエクスポートする
    # こともあります（その名前空間に存在する場合、つまり learntools.core から * をインポートしている場合）
    if '____' in g:
        yield '____'

def format_args(fn, args):
    c = fn.__code__
    params = c.co_varnames[:c.co_argcount]
    #assert len(args) == len(params)
    return ', '.join([
        '`{}={}`'.format(param, repr(arg))
        for (param, arg) in zip(params, args)
        ])
