from abc import ABC, abstractmethod
from typing import List
import functools

from learntools.core.richtext import *
from learntools.core.exceptions import NotAttempted, Uncheckable, UserlandExceptionIncorrect
from learntools.core import utils, asserts, constants

# もっとスマートな方法があると思います。
# property にデコレータを付けるとか。
def optionally_plural_property(obj, name):
    single_attr = getattr(obj, name, None)
    plural_attr = getattr(obj, name + 's', None)
    assert single_attr is None or plural_attr is None, (
        "サブクラスは「{0}」と「{0}s」の両方を実装しないでください。"
    ).format(name)
    if single_attr is not None:
        return [single_attr]
    elif plural_attr is not None:
        return plural_attr
    else:
        return []

class Problem(ABC):

    _solution = ''

    # valueTowardsCompletion の進捗管理に使用
    _counts_for_points = True
    _bonus = False

    @property
    def solution(self):
        return self._solution

    @property
    def hints(self) -> List[str]:
        return optionally_plural_property(self, '_hint')

    @property
    def _correct_message(self):
        if (
                self.show_solution_on_correct 
                or (self.show_solution_on_correct is None 
                    and isinstance(self.solution, str)
                    )
                ):
            return '\n\n' + self.solution
        else:
            return ''

    @abstractmethod
    def check(self, *args):
        """このメソッドが例外なく実行された場合、チェックが成功し解答が正しいことを示します。
        他の結果を示すには、以下のいずれかの例外を発生させてください:

        - Uncheckable: この問題に対してチェックロジックが定義されていない場合
        - NotAttempted: スターターコードが変更されておらず、問題が未着手と判断される場合
        - Incorrect, AssertionError: ユーザーの解答に誤りがある場合

        それぞれの例外に添付されたメッセージは、そのままユーザーへの表示メッセージとして渡されます。
        """
        pass

    def check_whether_attempted(self, *args):
        pass

class ThoughtExperiment(Problem):

    show_solution_on_correct = True
    def check(self, *args):
        pass

# TODO: EqualityCheckProblem.checkなどに直接適用できるようにする？
def injected(method):
    """Problem サブクラスのカスタムメソッド向けデコレータです。
    生徒のノートブックから取得した値を、CodingProblem サブクラスで
    .check() や .check_whether_attempted() などに自動的に注入引数が渡されるのと同じ方法で
    メソッドの引数として注入します。

    注入された引数のあとに、明示的にユーザーが指定する追加の引数を
    受け取ることも可能です。
    """
    @functools.wraps(method)
    def wrapped(self, *args, **kwargs):
        # ProblemとProblemViewの責任範囲がさらにあいまいになっています… :/
        # XXX: 未設定の変数を処理します。この呼び出しで NotAttemptedやIncorrectが発生する可能性があります。
        injargs = self._view._get_injected_args()
        # 注入する引数に加えて、ユーザー指定の引数がある場合があります
        # （例: python.ex3 の Blackjack 問題を参照してください）
        # 注入引数を先に渡し、そのあとに追加の引数を渡します。
        newargs = list(injargs) + list(args)
        return method(self, *newargs, **kwargs)

    return wrapped


class CodingProblem(Problem):
    # ユーザーが .check() を呼び出し、コードが正しいと判定されたときに
    # 何を表示するかを設定します。
    # False: 正解時にソリューションは表示せず、正解のメッセージだけを伝える
    # True: 「正解です」と表示したうえで、solution を表示（problem.solution() 呼び出しと同等）
    # None: デフォルト。solution が文字列なら表示、CodeSolution のインスタンスなら非表示
    show_solution_on_correct = None

    _var = None
    _vars = None
    # NotAttempted 判定のために、_default_values クラス属性を設定できます

    @property
    def injectable_vars(self) -> List[str]:
        return optionally_plural_property(self, '_var')

    def check_whether_attempted(self, *args):
        # TODO: EqualityCheckProblem.check_whether_attemptedからコピー＆ペースト
        varnames = self.injectable_vars
        def _raise_not_attempted():
            raise NotAttempted(
                "入力されていないか、内容が正しくない変数があります。もう一度、変数を確認してください: {}".format(
                    ', '.join(map(utils.backtickify, varnames))
                )
            )
        # まず、変数がプレースホルダーのままかどうかを確認します
        for (var, val) in zip(varnames, args):
            # NB: Yoda条件にすることでPlaceholderValueの__eq__が呼ばれるようにしています
            if constants.PLACEHOLDER == val:
                _raise_not_attempted()


class EqualityCheckProblem(CodingProblem):
    """ユーザーが定義した変数と正解値が等しい場合に「解答済み」と判定される問題です。

    サブクラスは、_varsと同じ順序・同じ長さの_expected属性に期待値のリストを
    設定するのが一般的です。

    変数が一つだけの場合は、_expectedにリストではなくスカラー値を直接設定できます。
    （ただし、期待値自体が長さ1のリストの場合は曖昧さを避けるためリストで
    包んでください。）
    """

    @property
    def expected(self):
        """期待値のリストです。_var/_vars の長さと順序に対応しています。"""
        ex = self._expected
        # 変数が1つだけの場合の特別扱い
        if len(self.injectable_vars) == 1:
            # 長さ1のリストはそのまま返します
            # （ex自体ではなく ex[0] が期待値だとみなすため）
            if (isinstance(ex, list) or isinstance(ex, tuple)) and len(ex) == 1:
                return ex
            else:
                return [ex]
        else:
            # 変数の数と期待値リストの長さが一致していることを確認
            assert len(ex) == len(self.injectable_vars)
            return ex

    def check(self, *args):
        for (var, actual, expected) in zip(self.injectable_vars, args, self.expected):
            asserts.assert_equal(actual, expected, var=var,
                    failure_factory=getattr(self, '_failure_message', None)
                    )

    def check_whether_attempted(self, *args):
        varnames = self.injectable_vars

        def _raise_not_attempted():
            raise NotAttempted(
                "入力されていないか、内容が正しくない変数があります。次の変数を確認してください: {}".format(
                    ', '.join(map(utils.backtickify, varnames))
                )
            )

        # まず、プレースホルダーのままの変数がないかを確認します
        for (var, val) in zip(varnames, args):
            # PlaceholderValue の __eq__ が正しく呼ばれるよう、Yoda条件で比較しています
            if constants.PLACEHOLDER == val:
                _raise_not_attempted()

        if not hasattr(self, '_default_values'):
            return
        for var, val, default in zip(
                varnames, args, self._default_values
                ):
            try:
                neq = val != default
            except:
                # actual値とdefaultを比較中に例外が発生した場合は、
                # 異なるものとみなします
                neq = True
            # ndarrayやDataFrameなどの場合、!= の結果がbool以外になることがあります。
            # その際は、実際の値がデフォルトと異なると判断します。
            # （デフォルト値がndarray/df/seriesのような複雑な型になることはまずないため）
            if not isinstance(neq, bool):
                return

            if neq:
                return
        # EqualityCheckProblem に変数がまったく紐付いていないのは不自然ですが、
        # 大騒ぎするほどではないはずです
        if len(args):
            _raise_not_attempted()

class FunctionProblem(CodingProblem):

    # 関数名を表す_varは必ず1つだけ設定してください

    # (入力, 期待される出力)のペアを並べたリストです。
    # 入力はスカラー値または引数のタプルで指定できます。
    _test_cases = []
    
    @classmethod
    def check_whether_attempted(cls, fn):
        # inspect.getsource()が確実に動作するかはわかりませんが、
        # IPythonノートブックでは問題なく動いているようです。
        def dummy():
            pass
        def dummy_w_docstring():
            """blah blah fishcakes"""

    @classmethod
    def check_whether_attempted(cls, fn):
        # Not sure if inspect.getsource() will work reliably? Seems like it does
        # work okay with ipython notebooks. 
        def dummy(): 
            pass

        def dummy_w_docstring():
            """blah blah fishcakes"""

            pass
        # 補足: バイトコード上では pass が return None と同じ扱いになるようです。
        # そのため、定数を返すだけの他の関数とも一致してしまう可能性があります。
        # 少々不安定で危険かもしれません。
        src = lambda f: f.__code__.co_code
        if src(fn) in (src(dummy), src(dummy_w_docstring)):
            raise NotAttempted

    def check(self, fn):
        # テストケースが定義されていることを確認します
        assert self._test_cases, "テストケースが定義されていません。"

        for args, expected in self._test_cases:
            orig_args = args
            # 必要に応じてタプルに変換します
            if not isinstance(args, tuple):
                args = (args,)

            # XXX: ミューテーション（変更）による副作用を防ぐ必要があります
            # コピー・メソッドを持たない、あるいはディープコピーが必要な
            # 複雑な可変オブジェクトにも注意してください。
            # このレベルで対処するのではなく、テストケースを呼び出すたびに
            # 新鮮なリストを生成するメソッドを用意する方が、
            # 静的属性として保持するよりもいいかもしれません。

            # 引数のリストをコピーしてミューテーションによる副作用を防ぎます
            args = [arg.copy() if hasattr(arg, 'copy') else arg for arg in args]
            orig_args = [arg.copy() if hasattr(arg, 'copy') else arg for arg in args]
            try:
                actual = fn(*args)
            except Exception as e:
                # ユーザー実装側で例外が発生した場合は、UserlandExceptionIncorrect を投げる
                raise UserlandExceptionIncorrect(e, orig_args)

            # 戻り値がNoneだとき、本来は何らかの値を返すはずだった
            assert not (actual is None and expected is not None), (
                "引数 {} のとき、戻り値が `None` でしたが、型 `{}` の値が必要でした。"
                " (`return` 文を忘れていませんか？)"
            ).format(utils.format_args(fn, orig_args), type(expected).__name__)

            # 期待どおりの戻り値と比較して一致するかチェック
            assert actual == expected, (
                "引数 {} のとき、戻り値として `{}` が期待されましたが、実際には `{}` が返されました。"
            ).format(repr(expected), utils.format_args(fn, orig_args), repr(actual))
            
__all__ = ['Problem', 'EqualityCheckProblem', 'FunctionProblem',
        'ThoughtExperiment', 'CodingProblem',
        ]
