import enum
from IPython.display import display, Javascript
import json
import learntools
import os

# True に設定すると、ログに記録されたイベントが出力として表示されます。
DEBUG = False


# USE_KAGGLESDK = os.environ.get('LEARN_USE_KAGGLE_SDK') == 'True'
USE_KAGGLESDK = False

if USE_KAGGLESDK:
    from kagglesdk import KaggleClient
    from kagglesdk.education.types.education_api_service import ApiTrackExerciseInteractionRequest
    from kagglesdk.education.types.education_service import LearnExerciseInteractionType, LearnExerciseOutcomeType, LearnExerciseQuestionType

class InteractionType(enum.Enum):
    CHECK = 1
    HINT = 2
    SOLUTION = 3

class OutcomeType(enum.Enum):
    PASS = 1
    FAIL = 2
    EXCEPTION = 3
    UNATTEMPTED = 4

class QuestionType(enum.Enum):
    EQUALITYCHECKPROBLEM = 1
    CODINGPROBLEM = 2
    FUNCTIONPROBLEM = 3
    THOUGHTEXPERIMENT = 4

_EVENT_DEFAULTS = dict(
        learnToolsVersion = str(learntools.__version__),
        valueTowardsCompletion = 0.0,
        failureMessage = '',
        exceptionClass = '',
        trace = '',
)

def interaction_type_to_kagglesdk(event):
  switch = {
      InteractionType.CHECK: LearnExerciseInteractionType.CHECK,
      InteractionType.HINT: LearnExerciseInteractionType.HINT,
      InteractionType.SOLUTION: LearnExerciseInteractionType.SOLUTION,
  }
  value = event['interactionType']
  assert value in switch
  return switch.get(value)

def outcome_type_to_kagglesdk(interaction_type, event):
    switch = {
        OutcomeType.PASS: LearnExerciseOutcomeType.PASS,
        OutcomeType.FAIL: LearnExerciseOutcomeType.FAIL,
        OutcomeType.EXCEPTION: LearnExerciseOutcomeType.EXCEPTION,
        OutcomeType.UNATTEMPTED: LearnExerciseOutcomeType.UNATTEMPTED,
    }

    value = event.get('outcomeType', None)
    if value:
        assert value in switch
        return switch.get(value)
    else:
        assert interaction_type != LearnExerciseInteractionType.CHECK, "チェックイベントには OutcomeType が設定されている必要があります: {!r}".format(event)
        return LearnExerciseOutcomeType.LEARN_EXERCISE_OUTCOME_TYPE_UNSPECIFIED

def question_type_to_kagglesdk(event):
    switch = {
        QuestionType.EQUALITYCHECKPROBLEM: LearnExerciseQuestionType.EQUALITY_CHECK_PROBLEM,
        QuestionType.CODINGPROBLEM: LearnExerciseQuestionType.CODING_PROBLEM,
        QuestionType.FUNCTIONPROBLEM: LearnExerciseQuestionType.FUNCTION_PROBLEM,
        QuestionType.THOUGHTEXPERIMENT: LearnExerciseQuestionType.THOUGHT_EXPERIMENT,
    }

    question_type = event.get('questionType', None)
    if question_type:
        assert question_type in switch
        return switch.get(question_type)
    return None

def track_using_kagglesdk(event):
    request = ApiTrackExerciseInteractionRequest()
    request.learn_tools_version = str(learntools.__version__)
    request.value_towards_completion = event.get('valueTowardsCompletion', 0.0)
    request.interaction_type = interaction_type_to_kagglesdk(event)
    request.outcome_type = outcome_type_to_kagglesdk(request.interaction_type, event)

    question_type = question_type_to_kagglesdk(event)
    if question_type:
        request.question_type = question_type

    # TODO(b/379083750): 次の項目はまだ未決定です
    #   - request.fork_parent_kernel_session_id を設定する
    #   - KaggleClientで認証を自動的に処理する
    #   - クライアントに対してナッジ情報を投稿する

    client = KaggleClient()
    result = client.education.education_api_client.track_exercise_interaction(request)

def track_using_iframe(event):
    # TODO: ここに検証ロジックを追加できると良い
    for k, v in _EVENT_DEFAULTS.items():
        event.setdefault(k, v)

    # 列挙型の値を単純な整数に変換
    interaction_type = event['interactionType']
    assert interaction_type in InteractionType
    event['interactionType'] = interaction_type.value
    outcome_type = event.get('outcomeType', None)
    if outcome_type:
        assert outcome_type in OutcomeType
        event['outcomeType'] = outcome_type.value
    else:
        assert interaction_type != InteractionType.CHECK, "チェックイベントには OutcomeType が設定されている必要があります: {!r}".format(event)
        # このフィールドが適用されない場合でも（チェックイベントでないため）、ダミーの値を設定する必要があるようです。
        # outcomeType を None または null に設定すると 500 エラーが発生したため、ここでは 4 を設定します。
        event['outcomeType'] = 4

    question_type = event.get('questionType', None)
    if question_type:
        assert question_type in QuestionType
        event['questionType'] = question_type.value

    message = dict(jupyterEvent='custom.exercise_interaction',
            data=event)
    js = 'parent.postMessage({}, "*")'.format(json.dumps(message))
    display(Javascript(js))
    if DEBUG:
        debug_js = 'console.log({})'.format(json.dumps(message))
        display(Javascript(debug_js))
        display(message)

def track(event):
    if USE_KAGGLESDK:
        track_using_kagglesdk(event)
    else:
        track_using_iframe(event)
    