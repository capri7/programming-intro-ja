import logging

# カスタム例外を定義
class BinderException(Exception):
    """Binderに関連する例外"""
    pass

class KeyNotFoundError(Exception):
    """キーが見つからない場合の例外"""
    pass

# このクラスは、グローバル変数（globals 辞書）への参照を保持し、チェック処理からアクセスできるようにします。

class Binder:
    
    def __init__(self):
        self.bound = False  # すでにバインド済みかどうかを示すフラグ
        self.g = None       # グローバル変数（dict）への参照

    def bind(self, global_vars):
        # すでにバインド済みの場合
        if self.bound:
            # 同じオブジェクトを再度バインドしようとしている場合は警告を出すだけで無視
            if id(global_vars) == id(self.g):
                logging.warning("すでにバインドされている globals への再バインドは無視されました")
            else:
                # 異なる globals をバインドしようとした場合は例外を発生
                raise Exception("すでにバインドされた Binder に別の globals をバインドしようとしました")
        else:
            # 初回バインド時は globals を記録
            self.g = global_vars
            self.bound = True

    def readonly_globals(self):
        # 読み取り専用のグローバル変数ラッパーを返す
        return ReadOnlyGlobals(self.g)


class ReadOnlyGlobals:
    """捕捉した globals 辞書の読み取り専用ラッパー、および便利なメソッド
    """

    def __init__(self, g):
        self.g = g

    def __getitem__(self, key):
        # キーが存在しない場合にカスタム例外を発生させる
        if key not in self.g:
            raise KeyNotFoundError(f"キー `{key}` が見つかりませんでした")
        return self.g[key]

    def __contains__(self, key):
        return key in self.g

    def keys(self):
        return self.g.keys()

    def lookup(self, keys):
        return [self.g[k] for k in keys]

    # __setitem__ は定義しない（変更不可）

# Binderインスタンスの作成

binder = Binder()



